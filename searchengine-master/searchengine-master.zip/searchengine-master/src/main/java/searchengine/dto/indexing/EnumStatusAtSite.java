package searchengine.dto.indexing;

public enum EnumStatusAtSite {
    INDEXING,
    INDEXED,
    FAILED
}
